<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="TileSet3" tilewidth="16" tileheight="16" tilecount="36" columns="6">
 <image source="TileSet3.png" width="96" height="96"/>
 <tile id="1">
  <animation>
   <frame tileid="1" duration="167"/>
   <frame tileid="2" duration="167"/>
   <frame tileid="3" duration="167"/>
   <frame tileid="4" duration="167"/>
   <frame tileid="5" duration="167"/>
  </animation>
 </tile>
</tileset>
