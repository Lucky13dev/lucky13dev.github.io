package de.catepilla.gdxtesting.examples;

import Sprites.InteractiveTileObject;
import de.catepilla.gdxtesting.GdxTestRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(GdxTestRunner.class)
public class InteractiveTileObjectTests {

    @Test
    public void InteractiveTileObjectTest(){

    }

}
