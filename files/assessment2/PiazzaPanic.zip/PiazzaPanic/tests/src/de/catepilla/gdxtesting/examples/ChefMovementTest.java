package de.catepilla.gdxtesting.examples;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import Sprites.Chef;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.team13.piazzapanic.GameState;
import de.catepilla.gdxtesting.GdxTestRunner;
import org.junit.runner.RunWith;

/**
 * Tests for the FR_MOVEMENT requirement.
 */
@RunWith(GdxTestRunner.class)
public class ChefMovementTest {

//    public void ChefMovementTests(){
//          //TODO: Test commented out due to it not being complete.
//        Chef chef = new Chef(0,0);
//        GameState gameState = new GameState();
//
//        Gdx.input.isKeyPressed(Input.Keys.W);
//
//    }
}
