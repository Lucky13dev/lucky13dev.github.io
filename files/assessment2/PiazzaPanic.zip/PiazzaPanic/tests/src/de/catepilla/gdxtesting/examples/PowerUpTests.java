package de.catepilla.gdxtesting.examples;

import PowerUps.PowerUp;
import Sprites.PowerUpStation;
import de.catepilla.gdxtesting.GdxTestRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(GdxTestRunner.class)
public class PowerUpTests {

    /**
     * Tests on the different types of PowerUps.
     */
//    @Test
//    public void FreeRecipePUPTest() {
//        PowerUpStation pus = (PowerUpStation) tile;
//        PowerUp pUp = pus.getPowerUp();
//    }
    /**Gamestate is needed for testing the powerups, and it is private.**/
}
