package de.catepilla.gdxtesting.examples;

import de.catepilla.gdxtesting.GdxTestRunner;
import org.junit.runner.RunWith;

/**
 * Tests the FR_POWERUPS requirement.
 */
@RunWith(GdxTestRunner.class)
public class PowerUpTests {

    /**
     * Tests on the different types of PowerUps.
     */
//    @Test
//    public void FreeRecipePUPTest() {
//        PowerUpStation pus = (PowerUpStation) tile;
//        PowerUp pUp = pus.getPowerUp();
//    }
    /**Gamestate is needed for testing the powerups, and it is private.**/
}
